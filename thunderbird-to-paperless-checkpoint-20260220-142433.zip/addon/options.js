const form = document.getElementById("settings-form");
const serverUrlInput = document.getElementById("server-url");
const apiTokenInput = document.getElementById("api-token");
const titlePrefixInput = document.getElementById("title-prefix");
const confirmBeforeUploadInput = document.getElementById("confirm-before-upload");
const defaultCorrespondentIdInput = document.getElementById("default-correspondent-id");
const defaultDocumentTypeIdInput = document.getElementById("default-document-type-id");
const defaultTagIdsInput = document.getElementById("default-tag-ids");
const statusEl = document.getElementById("status");

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#a4000f" : "#0a6700";
}

function normalizeUrl(raw) {
  const trimmed = raw.trim();
  const parsed = new URL(trimmed);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("URL must start with http:// or https://");
  }
  return parsed.toString().replace(/\/$/, "");
}

function validateOptionalPositiveInt(raw, label) {
  const value = raw.trim();
  if (!value) {
    return "";
  }

  const n = Number(value);
  if (!Number.isInteger(n) || n <= 0) {
    throw new Error(`${label} must be a positive integer.`);
  }

  return String(n);
}

function validateTagIds(raw) {
  const value = raw.trim();
  if (!value) {
    return "";
  }

  const normalized = value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);

  for (const item of normalized) {
    const n = Number(item);
    if (!Number.isInteger(n) || n <= 0) {
      throw new Error("Tag IDs must be comma-separated positive integers.");
    }
  }

  return normalized.join(",");
}

async function loadSettings() {
  const data = await messenger.storage.local.get({
    serverUrl: "",
    apiToken: "",
    titlePrefix: "",
    confirmBeforeUpload: true,
    defaultCorrespondentId: "",
    defaultDocumentTypeId: "",
    defaultTagIds: ""
  });

  serverUrlInput.value = data.serverUrl || "";
  apiTokenInput.value = data.apiToken || "";
  titlePrefixInput.value = data.titlePrefix || "";
  confirmBeforeUploadInput.checked = data.confirmBeforeUpload !== false;
  defaultCorrespondentIdInput.value = data.defaultCorrespondentId || "";
  defaultDocumentTypeIdInput.value = data.defaultDocumentTypeId || "";
  defaultTagIdsInput.value = data.defaultTagIds || "";
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  try {
    const serverUrl = normalizeUrl(serverUrlInput.value);
    const apiToken = apiTokenInput.value.trim();
    const titlePrefix = titlePrefixInput.value;
    const confirmBeforeUpload = confirmBeforeUploadInput.checked;
    const defaultCorrespondentId = validateOptionalPositiveInt(
      defaultCorrespondentIdInput.value,
      "Correspondent ID"
    );
    const defaultDocumentTypeId = validateOptionalPositiveInt(
      defaultDocumentTypeIdInput.value,
      "Document type ID"
    );
    const defaultTagIds = validateTagIds(defaultTagIdsInput.value);

    if (!apiToken) {
      throw new Error("API token is required.");
    }

    await messenger.storage.local.set({
      serverUrl,
      apiToken,
      titlePrefix,
      confirmBeforeUpload,
      defaultCorrespondentId,
      defaultDocumentTypeId,
      defaultTagIds
    });

    setStatus("Settings saved.");
  } catch (error) {
    setStatus(error.message || "Failed to save settings.", true);
  }
});

loadSettings().catch((error) => {
  setStatus(error.message || "Failed to load settings.", true);
});
