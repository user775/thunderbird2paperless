const params = new URLSearchParams(window.location.search);
const nonce = params.get("nonce") || "";
const attachmentName = params.get("attachment") || "attachment";

const attachmentNameEl = document.getElementById("attachment-name");
const form = document.getElementById("confirm-form");
const titleInput = document.getElementById("title");
const correspondentIdInput = document.getElementById("correspondent-id");
const documentTypeIdInput = document.getElementById("document-type-id");
const tagIdsInput = document.getElementById("tag-ids");
const statusEl = document.getElementById("status");
const cancelButton = document.getElementById("cancel");

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#a4000f" : "#0a6700";
}

async function loadDefaults() {
  attachmentNameEl.textContent = `Attachment: ${attachmentName}`;

  if (!nonce) {
    throw new Error("Missing confirmation nonce.");
  }

  const response = await messenger.runtime.sendMessage({
    type: "paperless.getConfirmationDefaults",
    nonce
  });

  if (!response || !response.ok) {
    throw new Error((response && response.error) || "Failed to load defaults.");
  }

  titleInput.value = response.defaults.title || "";
  correspondentIdInput.value = response.defaults.correspondentId || "";
  documentTypeIdInput.value = response.defaults.documentTypeId || "";
  tagIdsInput.value = response.defaults.tagIds || "";
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  const response = await messenger.runtime.sendMessage({
    type: "paperless.submitConfirmation",
    nonce,
    payload: {
      title: titleInput.value,
      correspondentId: correspondentIdInput.value,
      documentTypeId: documentTypeIdInput.value,
      tagIds: tagIdsInput.value
    }
  });

  if (!response || !response.ok) {
    setStatus((response && response.error) || "Failed to submit.", true);
    return;
  }

  window.close();
});

cancelButton.addEventListener("click", async () => {
  await messenger.runtime.sendMessage({
    type: "paperless.cancelConfirmation",
    nonce
  });
  window.close();
});

loadDefaults().catch((error) => {
  setStatus(error.message || "Failed to initialize dialog.", true);
});
