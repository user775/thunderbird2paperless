const MENU_UPLOAD_ONE = "upload-attachment-to-paperless";
const MENU_UPLOAD_ALL = "upload-all-attachments-to-paperless";

function normalizeBaseUrl(rawUrl) {
  const url = (rawUrl || "").trim().replace(/\/$/, "");
  if (!url) {
    throw new Error("Paperless URL is not configured.");
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("Paperless URL is invalid.");
  }

  if (!(parsed.protocol === "http:" || parsed.protocol === "https:")) {
    throw new Error("Paperless URL must use http or https.");
  }

  return parsed.toString().replace(/\/$/, "");
}

async function getSettings() {
  const data = await messenger.storage.local.get({
    serverUrl: "",
    apiToken: "",
    titlePrefix: ""
  });

  if (!data.serverUrl || !data.apiToken) {
    throw new Error("Paperless settings are incomplete. Configure server URL and API token in add-on preferences.");
  }

  return {
    serverUrl: normalizeBaseUrl(data.serverUrl),
    apiToken: data.apiToken.trim(),
    titlePrefix: (data.titlePrefix || "").trim()
  };
}

function formatDateForPaperless(dateValue) {
  if (!dateValue) {
    return "";
  }

  const d = new Date(dateValue);
  if (Number.isNaN(d.getTime())) {
    return "";
  }

  const yyyy = d.getFullYear();
  const mm = `${d.getMonth() + 1}`.padStart(2, "0");
  const dd = `${d.getDate()}`.padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

async function inferMessageId(info, tab) {
  const first = info.attachments && info.attachments[0];
  if (first && first.message && first.message.id) {
    return first.message.id;
  }

  const selectedFromInfo = info.selectedMessages && info.selectedMessages.messages;
  if (selectedFromInfo && selectedFromInfo.length > 0) {
    return selectedFromInfo[0].id;
  }

  async function fromTabId(tabId) {
    if (typeof tabId !== "number") {
      return null;
    }

    try {
      const displayed = await messenger.messageDisplay.getDisplayedMessage(tabId);
      if (displayed && displayed.id) {
        return displayed.id;
      }
    } catch {
      // Ignore and try other strategies.
    }

    try {
      const selected = await messenger.mailTabs.getSelectedMessages(tabId);
      if (selected && selected.messages && selected.messages.length > 0) {
        return selected.messages[0].id;
      }
    } catch {
      // Ignore and try other strategies.
    }

    return null;
  }

  if (tab && typeof tab.id === "number") {
    const fromClickedTab = await fromTabId(tab.id);
    if (fromClickedTab) {
      return fromClickedTab;
    }
  }

  try {
    const activeMailTabs = await messenger.mailTabs.query({
      active: true,
      currentWindow: true
    });
    for (const mailTab of activeMailTabs) {
      const id = await fromTabId(mailTab.id);
      if (id) {
        return id;
      }
    }
  } catch {
    // Ignore and fall through to null.
  }

  return null;
}

async function uploadAttachment({ file, originalName, messageDate, settings }) {
  const endpoint = `${settings.serverUrl}/api/documents/post_document/`;
  const formData = new FormData();
  formData.append("document", file, originalName || file.name || "attachment");

  const titlePrefix = settings.titlePrefix;
  if (titlePrefix) {
    formData.append("title", `${titlePrefix}${originalName || file.name || "attachment"}`);
  }

  const created = formatDateForPaperless(messageDate);
  if (created) {
    formData.append("created", created);
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Token ${settings.apiToken}`
    },
    body: formData
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Upload failed (${response.status}). ${detail.slice(0, 250)}`);
  }
}

async function notify(title, message) {
  await messenger.notifications.create({
    type: "basic",
    title,
    message
  });
}

async function runUpload(info, tab) {
  const attachments = info.attachments || [];
  if (attachments.length === 0) {
    await notify("Paperless upload", "No attachments were selected.");
    return;
  }

  let settings;
  try {
    settings = await getSettings();
  } catch (error) {
    await notify("Paperless upload", error.message);
    await messenger.runtime.openOptionsPage();
    return;
  }

  const messageId = await inferMessageId(info, tab);
  if (!messageId) {
    await notify("Paperless upload", "Could not determine the source message.");
    return;
  }

  let messageDate = "";
  try {
    const message = await messenger.messages.get(messageId);
    messageDate = message && message.date ? message.date : "";
  } catch {
    messageDate = "";
  }

  let successCount = 0;
  const failures = [];

  for (const attachment of attachments) {
    try {
      if (!attachment.partName) {
        throw new Error(`Attachment \"${attachment.name || "(unnamed)"}\" has no partName.`);
      }

      const file = await messenger.messages.getAttachmentFile(messageId, attachment.partName);
      await uploadAttachment({
        file,
        originalName: attachment.name,
        messageDate,
        settings
      });
      successCount += 1;
    } catch (error) {
      failures.push(`${attachment.name || "(unnamed)"}: ${error.message}`);
    }
  }

  if (failures.length === 0) {
    await notify("Paperless upload", `Uploaded ${successCount} attachment(s).`);
    return;
  }

  const firstFailure = failures[0];
  await notify(
    "Paperless upload",
    `Uploaded ${successCount}/${attachments.length}. First error: ${firstFailure}`
  );
}

messenger.menus.create({
  id: MENU_UPLOAD_ONE,
  title: "Upload to Paperless-ngx",
  contexts: ["message_attachments"]
});

messenger.menus.create({
  id: MENU_UPLOAD_ALL,
  title: "Upload all attachments to Paperless-ngx",
  contexts: ["all_message_attachments"]
});

messenger.menus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_UPLOAD_ONE && info.menuItemId !== MENU_UPLOAD_ALL) {
    return;
  }

  await runUpload(info, tab);
});

messenger.runtime.onInstalled.addListener(() => {
  messenger.runtime.openOptionsPage();
});
