const form = document.getElementById("settings-form");
const serverUrlInput = document.getElementById("server-url");
const apiTokenInput = document.getElementById("api-token");
const titlePrefixInput = document.getElementById("title-prefix");
const statusEl = document.getElementById("status");

function setStatus(message, isError = false) {
  statusEl.textContent = message;
  statusEl.style.color = isError ? "#a4000f" : "#0a6700";
}

function normalizeUrl(raw) {
  const trimmed = raw.trim();
  const parsed = new URL(trimmed);
  if (parsed.protocol !== "http:" && parsed.protocol !== "https:") {
    throw new Error("URL must start with http:// or https://");
  }
  return parsed.toString().replace(/\/$/, "");
}

async function loadSettings() {
  const data = await messenger.storage.local.get({
    serverUrl: "",
    apiToken: "",
    titlePrefix: ""
  });

  serverUrlInput.value = data.serverUrl || "";
  apiTokenInput.value = data.apiToken || "";
  titlePrefixInput.value = data.titlePrefix || "";
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();

  try {
    const serverUrl = normalizeUrl(serverUrlInput.value);
    const apiToken = apiTokenInput.value.trim();
    const titlePrefix = titlePrefixInput.value;

    if (!apiToken) {
      throw new Error("API token is required.");
    }

    await messenger.storage.local.set({
      serverUrl,
      apiToken,
      titlePrefix
    });

    setStatus("Settings saved.");
  } catch (error) {
    setStatus(error.message || "Failed to save settings.", true);
  }
});

loadSettings().catch((error) => {
  setStatus(error.message || "Failed to load settings.", true);
});
