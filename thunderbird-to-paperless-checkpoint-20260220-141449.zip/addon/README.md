# Thunderbird to Paperless-ngx add-on

This add-on adds context-menu actions on email attachments in Thunderbird:

- `Upload to Paperless-ngx` (for selected attachment(s))
- `Upload all attachments to Paperless-ngx`

It uploads each attachment to Paperless-ngx using:

- `POST /api/documents/post_document/`
- `Authorization: Token <api-token>`

## Configure

1. Install the add-on as a temporary add-on in Thunderbird from this folder's `manifest.json`.
2. Open the add-on preferences.
3. Set:
   - Paperless URL (for example, `http://paperless.local:8000`)
   - API token
   - Optional title prefix

## Notes

- The add-on sends the attachment file and message date (`created`) when available.
- The add-on currently uses broad host permissions (`http://*/*`, `https://*/*`) to allow local-network URLs.
