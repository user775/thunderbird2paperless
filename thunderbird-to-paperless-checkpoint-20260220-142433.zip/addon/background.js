const MENU_UPLOAD_ONE = "upload-attachment-to-paperless";
const MENU_UPLOAD_ALL = "upload-all-attachments-to-paperless";

const confirmationSessions = new Map();

function normalizeBaseUrl(rawUrl) {
  const url = (rawUrl || "").trim().replace(/\/$/, "");
  if (!url) {
    throw new Error("Paperless URL is not configured.");
  }

  let parsed;
  try {
    parsed = new URL(url);
  } catch {
    throw new Error("Paperless URL is invalid.");
  }

  if (!(parsed.protocol === "http:" || parsed.protocol === "https:")) {
    throw new Error("Paperless URL must use http or https.");
  }

  return parsed.toString().replace(/\/$/, "");
}

function parseOptionalPositiveInt(rawValue, label) {
  const raw = String(rawValue ?? "").trim();
  if (!raw) {
    return null;
  }

  const value = Number(raw);
  if (!Number.isInteger(value) || value <= 0) {
    throw new Error(`${label} must be a positive integer.`);
  }

  return value;
}

function parseTagIds(rawTagIds) {
  const raw = String(rawTagIds ?? "").trim();
  if (!raw) {
    return [];
  }

  return raw
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean)
    .map((item) => {
      const id = Number(item);
      if (!Number.isInteger(id) || id <= 0) {
        throw new Error("Tag IDs must be comma-separated positive integers.");
      }
      return id;
    });
}

function formatTagIds(tagIds) {
  if (!Array.isArray(tagIds) || tagIds.length === 0) {
    return "";
  }

  return tagIds.join(", ");
}

function buildDefaultTitle(subject, attachmentName, titlePrefix) {
  const cleanSubject = String(subject || "").trim();
  const cleanAttachment = String(attachmentName || "attachment").trim() || "attachment";
  const base = cleanSubject ? `${cleanSubject} - ${cleanAttachment}` : cleanAttachment;
  const prefix = String(titlePrefix || "").trim();
  return `${prefix}${base}`;
}

function createNonce() {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 11)}`;
}

async function getSettings() {
  const data = await messenger.storage.local.get({
    serverUrl: "",
    apiToken: "",
    titlePrefix: "",
    confirmBeforeUpload: true,
    defaultCorrespondentId: "",
    defaultDocumentTypeId: "",
    defaultTagIds: ""
  });

  if (!data.serverUrl || !data.apiToken) {
    throw new Error("Paperless settings are incomplete. Configure server URL and API token in add-on preferences.");
  }

  return {
    serverUrl: normalizeBaseUrl(data.serverUrl),
    apiToken: data.apiToken.trim(),
    titlePrefix: (data.titlePrefix || "").trim(),
    confirmBeforeUpload: data.confirmBeforeUpload !== false,
    defaultCorrespondentId: parseOptionalPositiveInt(data.defaultCorrespondentId, "Default correspondent ID"),
    defaultDocumentTypeId: parseOptionalPositiveInt(data.defaultDocumentTypeId, "Default document type ID"),
    defaultTagIds: parseTagIds(data.defaultTagIds)
  };
}

function formatDateForPaperless(dateValue) {
  if (!dateValue) {
    return "";
  }

  const d = new Date(dateValue);
  if (Number.isNaN(d.getTime())) {
    return "";
  }

  const yyyy = d.getFullYear();
  const mm = `${d.getMonth() + 1}`.padStart(2, "0");
  const dd = `${d.getDate()}`.padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

async function inferMessageId(info, tab) {
  const first = info.attachments && info.attachments[0];
  if (first && first.message && first.message.id) {
    return first.message.id;
  }

  const selectedFromInfo = info.selectedMessages && info.selectedMessages.messages;
  if (selectedFromInfo && selectedFromInfo.length > 0) {
    return selectedFromInfo[0].id;
  }

  async function fromTabId(tabId) {
    if (typeof tabId !== "number") {
      return null;
    }

    try {
      const displayed = await messenger.messageDisplay.getDisplayedMessage(tabId);
      if (displayed && displayed.id) {
        return displayed.id;
      }
    } catch {
      // Ignore and try other strategies.
    }

    try {
      const selected = await messenger.mailTabs.getSelectedMessages(tabId);
      if (selected && selected.messages && selected.messages.length > 0) {
        return selected.messages[0].id;
      }
    } catch {
      // Ignore and try other strategies.
    }

    return null;
  }

  if (tab && typeof tab.id === "number") {
    const fromClickedTab = await fromTabId(tab.id);
    if (fromClickedTab) {
      return fromClickedTab;
    }
  }

  try {
    const activeMailTabs = await messenger.mailTabs.query({
      active: true,
      currentWindow: true
    });
    for (const mailTab of activeMailTabs) {
      const id = await fromTabId(mailTab.id);
      if (id) {
        return id;
      }
    }
  } catch {
    // Ignore and fall through to null.
  }

  return null;
}

async function uploadAttachment({ file, originalName, messageDate, settings, metadata }) {
  const endpoint = `${settings.serverUrl}/api/documents/post_document/`;
  const formData = new FormData();
  formData.append("document", file, originalName || file.name || "attachment");

  if (metadata.title) {
    formData.append("title", metadata.title);
  }

  if (metadata.correspondentId) {
    formData.append("correspondent", String(metadata.correspondentId));
  }

  if (metadata.documentTypeId) {
    formData.append("document_type", String(metadata.documentTypeId));
  }

  if (Array.isArray(metadata.tagIds)) {
    for (const tagId of metadata.tagIds) {
      formData.append("tags", String(tagId));
    }
  }

  const created = formatDateForPaperless(messageDate);
  if (created) {
    formData.append("created", created);
  }

  const response = await fetch(endpoint, {
    method: "POST",
    headers: {
      Authorization: `Token ${settings.apiToken}`
    },
    body: formData
  });

  if (!response.ok) {
    const detail = await response.text();
    throw new Error(`Upload failed (${response.status}). ${detail.slice(0, 250)}`);
  }
}

async function notify(title, message) {
  await messenger.notifications.create({
    type: "basic",
    title,
    message
  });
}

async function requestUploadMetadata(defaults, attachmentName) {
  const nonce = createNonce();
  const url = messenger.runtime.getURL(
    `confirm.html?nonce=${encodeURIComponent(nonce)}&attachment=${encodeURIComponent(attachmentName || "attachment")}`
  );

  return new Promise((resolve, reject) => {
    const session = {
      defaults,
      resolve,
      reject,
      windowId: null
    };

    confirmationSessions.set(nonce, session);

    messenger.windows
      .create({
        url,
        type: "popup",
        width: 560,
        height: 640
      })
      .then((popupWindow) => {
        session.windowId = popupWindow.id;
      })
      .catch((error) => {
        confirmationSessions.delete(nonce);
        reject(error);
      });
  });
}

function normalizeConfirmationPayload(payload, defaults) {
  const incoming = payload || {};
  const title = String(incoming.title ?? "").trim() || defaults.title;
  const correspondentId = parseOptionalPositiveInt(incoming.correspondentId, "Correspondent ID");
  const documentTypeId = parseOptionalPositiveInt(incoming.documentTypeId, "Document type ID");
  const tagIds = parseTagIds(incoming.tagIds);

  return {
    title,
    correspondentId,
    documentTypeId,
    tagIds
  };
}

messenger.runtime.onMessage.addListener(async (message) => {
  if (!message || !message.type) {
    return undefined;
  }

  if (message.type === "paperless.getConfirmationDefaults") {
    const session = confirmationSessions.get(message.nonce);
    if (!session) {
      return { ok: false, error: "Confirmation session expired." };
    }

    return {
      ok: true,
      defaults: {
        title: session.defaults.title,
        correspondentId: session.defaults.correspondentId ? String(session.defaults.correspondentId) : "",
        documentTypeId: session.defaults.documentTypeId ? String(session.defaults.documentTypeId) : "",
        tagIds: formatTagIds(session.defaults.tagIds)
      }
    };
  }

  if (message.type === "paperless.submitConfirmation") {
    const session = confirmationSessions.get(message.nonce);
    if (!session) {
      return { ok: false, error: "Confirmation session expired." };
    }

    try {
      const metadata = normalizeConfirmationPayload(message.payload, session.defaults);
      confirmationSessions.delete(message.nonce);
      session.resolve(metadata);
      return { ok: true };
    } catch (error) {
      return { ok: false, error: error.message || "Invalid confirmation data." };
    }
  }

  if (message.type === "paperless.cancelConfirmation") {
    const session = confirmationSessions.get(message.nonce);
    if (session) {
      confirmationSessions.delete(message.nonce);
      session.resolve(null);
    }

    return { ok: true };
  }

  return undefined;
});

messenger.windows.onRemoved.addListener((windowId) => {
  for (const [nonce, session] of confirmationSessions.entries()) {
    if (session.windowId === windowId) {
      confirmationSessions.delete(nonce);
      session.resolve(null);
      return;
    }
  }
});

async function runUpload(info, tab) {
  const attachments = info.attachments || [];
  if (attachments.length === 0) {
    await notify("Paperless upload", "No attachments were selected.");
    return;
  }

  let settings;
  try {
    settings = await getSettings();
  } catch (error) {
    await notify("Paperless upload", error.message);
    await messenger.runtime.openOptionsPage();
    return;
  }

  const messageId = await inferMessageId(info, tab);
  if (!messageId) {
    await notify("Paperless upload", "Could not determine the source message.");
    return;
  }

  let messageDate = "";
  let messageSubject = "";
  try {
    const message = await messenger.messages.get(messageId);
    messageDate = message && message.date ? message.date : "";
    messageSubject = message && message.subject ? message.subject : "";
  } catch {
    messageDate = "";
    messageSubject = "";
  }

  let successCount = 0;
  const failures = [];

  for (const attachment of attachments) {
    const attachmentName = attachment.name || "attachment";

    try {
      if (!attachment.partName) {
        throw new Error(`Attachment \"${attachmentName}\" has no partName.`);
      }

      const file = await messenger.messages.getAttachmentFile(messageId, attachment.partName);

      const defaultMetadata = {
        title: buildDefaultTitle(messageSubject, attachmentName, settings.titlePrefix),
        correspondentId: settings.defaultCorrespondentId,
        documentTypeId: settings.defaultDocumentTypeId,
        tagIds: settings.defaultTagIds
      };

      let metadata = defaultMetadata;
      if (settings.confirmBeforeUpload) {
        metadata = await requestUploadMetadata(defaultMetadata, attachmentName);
        if (!metadata) {
          failures.push(`${attachmentName}: canceled.`);
          continue;
        }
      }

      await uploadAttachment({
        file,
        originalName: attachment.name,
        messageDate,
        settings,
        metadata
      });
      successCount += 1;
    } catch (error) {
      failures.push(`${attachmentName}: ${error.message}`);
    }
  }

  if (failures.length === 0) {
    await notify("Paperless upload", `Uploaded ${successCount} attachment(s).`);
    return;
  }

  const firstFailure = failures[0];
  await notify(
    "Paperless upload",
    `Uploaded ${successCount}/${attachments.length}. First error: ${firstFailure}`
  );
}

messenger.menus.create({
  id: MENU_UPLOAD_ONE,
  title: "Upload to Paperless-ngx",
  contexts: ["message_attachments"]
});

messenger.menus.create({
  id: MENU_UPLOAD_ALL,
  title: "Upload all attachments to Paperless-ngx",
  contexts: ["all_message_attachments"]
});

messenger.menus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_UPLOAD_ONE && info.menuItemId !== MENU_UPLOAD_ALL) {
    return;
  }

  await runUpload(info, tab);
});

messenger.runtime.onInstalled.addListener(() => {
  messenger.runtime.openOptionsPage();
});
