# Thunderbird to Paperless-ngx add-on

This add-on adds context-menu actions on email attachments in Thunderbird:

- `Upload to Paperless-ngx` (for selected attachment(s))
- `Upload all attachments to Paperless-ngx`

It uploads each attachment to Paperless-ngx using:

- `POST /api/documents/post_document/`
- `Authorization: Token <api-token>`

## Configure

1. Install the add-on as a temporary add-on in Thunderbird from this folder's `manifest.json`.
2. Open the add-on preferences.
3. Set:
   - Paperless URL (for example, `http://paperless.local:8000`)
   - API token
   - Optional title prefix
   - Optional default metadata IDs:
     - Correspondent ID
     - Document Type ID
     - Tag IDs (comma-separated)
   - Whether to confirm metadata before each upload (enabled by default)

## Upload behavior

- Default title is auto-generated as `<message subject> - <attachment filename>`.
- Before upload, a popup lets you edit title and metadata IDs (if confirmation is enabled).
- The add-on sends message date as `created` when available.

## Notes

- The add-on uses broad host permissions (`http://*/*`, `https://*/*`) to allow local-network URLs.
- Metadata uses Paperless numeric IDs.
